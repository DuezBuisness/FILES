﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spotify.ID_MusicWF1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "J23ME9")
            {
                Process.Start("spotify://track:7jY6W92bLfnXnevTa7JKHi");
            }
            if (textBox1.Text == "DME1CF")
            {
                Process.Start("spotify://track:19Puyzzdl7fryhLRzUrGkC");
            }
            if (textBox1.Text == "MS24E1GO")
            {
                Process.Start("spotify://track:5lbFVZ3g63LLssXLKirfjA");
            }
            if (textBox1.Text == "E6H4EF1")
            {
                Process.Start("spotify://track:6waIROrW41DqlgD1Kh5TqO");
            }
            if (textBox1.Text == "F_SeI41")
            {
                Process.Start("spotify://track:0pPDkWdfYUpG2zkQlNbiBE");
            }
            if (textBox1.Text == "LF162M4")
            {
                Process.Start("spotify://track:3aq4uXTRtKg1BONQ21VlN2");
            }
            if (textBox1.Text == "BSDS991628")
            {
                Process.Start("spotify://track:6Gm86jjbNQZoc8tgyKhrpo");
            }
            if (textBox1.Text == "DNN916248")
            {
                Process.Start("spotify://track:34sGnIHB3ZthMvHpNX1i7e");
            }
            if (textBox1.Text == "I9G418G")
            {
                Process.Start("spotify://track:10w1VHXe5Ti6YK80yM9A8K");
            }
            if (textBox1.Text == "8DITI_416")
            {
                Process.Start("spotify://track:20on25jryn53hWghthWWW3");
            }
            if (textBox1.Text == "TMO_849I71")
            {
                Process.Start("spotify://track:0qaWEvPkts34WF68r8Dzx9");
            }
            if (textBox1.Text == "SeFA98.71")
            {
                Process.Start("spotify://track:05GvwwTLLID738BbKN1ze0");
            }
            if (textBox1.Text == "MYB_OS48.2")
            {
                Process.Start("spotify://track:6GomT970rCOkKAyyrwJeZi");
            }
            if (textBox1.Text == "MA_78941162")
            {
                Process.Start("spotify://track:28WRWusCLgWULI6Gv7h8DL");
            }
            if (textBox1.Text == "E99_B1_BFF6")
            {
                Process.Start("spotify://track:1di1BEgJYzPvXUuinsYJGP");
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            new Form2().Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("spotify://");
        }
    }
}
