﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HackConsole
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;
            string path = @"C:\Program Files (x86)\HackConsole\Application";
            Directory.CreateDirectory(path);
            string path2 = @"C:\Program Files (x86)\HackConsole\Application\HackConsole.exe.hub";
            string text = @"Application.32bits.Informations
-----------------------------------------
C#.i++;
i++.information(i++)
-----------------------------------------
32bits
-----------------------------------------
Website : https://geekprank.com/hacker
HomePage : https://geekprank.com ; https://google.com/?application
-----------------------------------------
32bits appliation";
            File.WriteAllText(path2, text);
            string path3 = @"C:\Program Files (x86)\HackConsole\Files";
            Directory.CreateDirectory (path3);
            string path4 = @"C:\Program Files (x86)\HackConsole\Files\website.url";
            string text2 = @"[{000214A0-0000-0000-C000-000000000046}]
Prop3=19,11
[InternetShortcut]
IDList=
URL=https://geekprank.com/hacker";
            File.WriteAllText (path4, text2);
        }
    }
}
