﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APM_Services
{
    public class AppHelper
    {
        public static bool Save(string server, string database, string username, string password)
        {
            string path = @"C:\APM-Services";
            System.IO.Directory.CreateDirectory(path);
            if (File.Exists(@"C:\APM-Services\config.ini"))
                File.Delete(@"C:\APM-Services\config.ini");
            File.WriteAllText(@"C:\APM-Services\config.ini", $"Server={server}, Database={database}, Username={username}, Password={password}");
            return true;
            
        }
    }
}
