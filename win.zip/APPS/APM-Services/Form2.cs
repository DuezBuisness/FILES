﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace APM_Services
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void aPMExplorerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://github.com/DuezBuisness/Files/raw/main/APM%20Explorer.exe");
        }

        private void uhost81001ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://github.com/DuezBuisness/Files/raw/main/Uhost8.1.0.0.1.exe");
        }

        private void githubWebToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://github.com/?application_link=902L29.redirection=https://github.com");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void shutdownToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("shutdown", "/s /t 0");
        }

        private void restartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("shutdown", "/r /t 0");
        }

        private void cMDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("cmd.exe");
        }
    }
}
