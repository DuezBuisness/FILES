﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Uhost8._1._0._0._1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void microsoftToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://microsoft.link/?we8.uhost:3!9=websource_login=application");
        }

        private void appsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://about.google/products");
        }

        private void exToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Êtes vous sûr de quitter ?", "EXIT", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void unistallToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Desinstaller Application ?", "Unistall", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if ( result == DialogResult.Yes )
            {
                Close();
                Thread.Sleep(3000);
                Form5 form5 = new Form5();
                form5.Show();
            }
        }

        private void francaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Installer ?", @"Windows Installer", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes )
            {
                System.Diagnostics.Process.Start("https://github.com/DuezBuisness/Files/raw/main/APM%20Explorer.exe");
            }
        }

        private void googleToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://google.com/?uhost8.1.0.0.1#home");
        }
    }
}
