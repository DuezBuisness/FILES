﻿namespace Uhost8._1._0._0._1
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.produitsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.microsoftUhostToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aPMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.explorerAPMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.francaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.googleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.appsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.applicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unistallToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.googleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.produitsToolStripMenuItem,
            this.applicationToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(989, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // produitsToolStripMenuItem
            // 
            this.produitsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.microsoftUhostToolStripMenuItem,
            this.aPMToolStripMenuItem,
            this.googleToolStripMenuItem});
            this.produitsToolStripMenuItem.Name = "produitsToolStripMenuItem";
            this.produitsToolStripMenuItem.Size = new System.Drawing.Size(94, 29);
            this.produitsToolStripMenuItem.Text = "Produits";
            // 
            // microsoftUhostToolStripMenuItem
            // 
            this.microsoftUhostToolStripMenuItem.Name = "microsoftUhostToolStripMenuItem";
            this.microsoftUhostToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.microsoftUhostToolStripMenuItem.Text = "Microsoft";
            this.microsoftUhostToolStripMenuItem.Click += new System.EventHandler(this.microsoftToolStripMenuItem_Click);
            // 
            // aPMToolStripMenuItem
            // 
            this.aPMToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.explorerAPMToolStripMenuItem});
            this.aPMToolStripMenuItem.Name = "aPMToolStripMenuItem";
            this.aPMToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.aPMToolStripMenuItem.Text = "APM";
            // 
            // explorerAPMToolStripMenuItem
            // 
            this.explorerAPMToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.francaisToolStripMenuItem});
            this.explorerAPMToolStripMenuItem.Name = "explorerAPMToolStripMenuItem";
            this.explorerAPMToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.explorerAPMToolStripMenuItem.Text = "APM Explorer";
            // 
            // francaisToolStripMenuItem
            // 
            this.francaisToolStripMenuItem.Name = "francaisToolStripMenuItem";
            this.francaisToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.francaisToolStripMenuItem.Text = "Français";
            this.francaisToolStripMenuItem.Click += new System.EventHandler(this.francaisToolStripMenuItem_Click);
            // 
            // googleToolStripMenuItem
            // 
            this.googleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.appsToolStripMenuItem,
            this.googleToolStripMenuItem1});
            this.googleToolStripMenuItem.Name = "googleToolStripMenuItem";
            this.googleToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.googleToolStripMenuItem.Text = "Google";
            // 
            // appsToolStripMenuItem
            // 
            this.appsToolStripMenuItem.Name = "appsToolStripMenuItem";
            this.appsToolStripMenuItem.Size = new System.Drawing.Size(156, 34);
            this.appsToolStripMenuItem.Text = "Apps";
            this.appsToolStripMenuItem.Click += new System.EventHandler(this.appsToolStripMenuItem_Click);
            // 
            // applicationToolStripMenuItem
            // 
            this.applicationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exToolStripMenuItem,
            this.unistallToolStripMenuItem});
            this.applicationToolStripMenuItem.Name = "applicationToolStripMenuItem";
            this.applicationToolStripMenuItem.Size = new System.Drawing.Size(118, 29);
            this.applicationToolStripMenuItem.Text = "Application";
            // 
            // exToolStripMenuItem
            // 
            this.exToolStripMenuItem.Name = "exToolStripMenuItem";
            this.exToolStripMenuItem.Size = new System.Drawing.Size(171, 34);
            this.exToolStripMenuItem.Text = "Exit";
            this.exToolStripMenuItem.Click += new System.EventHandler(this.exToolStripMenuItem_Click);
            // 
            // unistallToolStripMenuItem
            // 
            this.unistallToolStripMenuItem.Name = "unistallToolStripMenuItem";
            this.unistallToolStripMenuItem.Size = new System.Drawing.Size(171, 34);
            this.unistallToolStripMenuItem.Text = "Unistall";
            this.unistallToolStripMenuItem.Click += new System.EventHandler(this.unistallToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(251, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Uhost Products";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("ROG Fonts", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(184, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(317, 38);
            this.label2.TabIndex = 2;
            this.label2.Text = "By APM GROUP";
            // 
            // googleToolStripMenuItem1
            // 
            this.googleToolStripMenuItem1.Name = "googleToolStripMenuItem1";
            this.googleToolStripMenuItem1.Size = new System.Drawing.Size(270, 34);
            this.googleToolStripMenuItem1.Text = "Google";
            this.googleToolStripMenuItem1.Click += new System.EventHandler(this.googleToolStripMenuItem1_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(989, 417);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form4";
            this.Text = "Uhost8.1.0.0.1.exe";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem produitsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem microsoftUhostToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aPMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem explorerAPMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem francaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem googleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem appsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem applicationToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem exToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unistallToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem googleToolStripMenuItem1;
    }
}