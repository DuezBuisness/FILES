﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Antivirus
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = @"C:\
C:\Windows
C:ProgramDefender.Windows
C:\Program Files\WindowsApps
level:require Administrator
bfq0.exe
Xy0.link.exe
browser<link>.exe
urlbrowser.uf2.lnk
C++.WinExtension
C++.VisualStudio
C#.VisualStudio
System.Access";
            button2.Visible = true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Process.Start("https://dl-protect.link");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.ForeColor = Color.Red;
            richTextBox1.Text = @"4 virus :
\WindowsApps\virus666.exe
\WindowsApps\Defender666.exe
\fileroot#=%systemroot%, virus.exe
\visualstudio%root%virus-C++.exe";
            button3.Visible = true;
            button4.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = @"Error";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = @"Virus Infected C:\Windows\666.exe !
Windows Defender is not responding...
System Infected !";
            new Form2().Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "lol" && textBox2.Text == "lol")
            {
                new Form2().Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("The username or password is incorrect, please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Clear();
                textBox2.Clear();
                textBox1.Focus();
            }
        }
    }
}
