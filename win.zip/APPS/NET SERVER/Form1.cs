﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NET_SERVER
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex == 0)
            {
                label1.Text = comboBox1.Text;
                label2.Text = "Windows Server [LOCAL]";
            }
            if(comboBox1.SelectedIndex == 1)
            {
                label1.Text = comboBox1.Text;
                label2.Text = "HTTP SERVER [http://]\rHTTPS SERVER [https://]";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label3.Visible = false;
            comboBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Title = "Open Server";
            openFile.Filter = "User Database Server (*.uds)|*.uds";
            DialogResult result = openFile.ShowDialog();
            label3.Visible = true;
            label3.Text = "Server : " + openFile.FileName;
            if (result == DialogResult.OK)
            {
                new Form2().Show();
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            if (trackBar1.Value == 0)
            {
                DialogResult result = MessageBox.Show("Attention : l'application peut ne pas fonctionner correctement. Êtes vous sûr de continuer ?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    MessageBox.Show("Action validée.");
                }
                if (result == DialogResult.No)
                {
                    trackBar1.Value = 5;
                }
            }
            if (trackBar1.Value == 10)
            {
                MessageBox.Show("Performance maximale activée.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information); ;
            }
        }
    }
}
