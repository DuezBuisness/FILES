﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Contrôle_de_Windows
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Text = "!Crash System!";
            Thread.Sleep(999999999);
            Thread.Sleep(999999999);
        }

        private async void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            button1.Text = "Saving...";
            await Task.Delay(2000);
            button1.Text = "Saving system...";
            await Task.Delay(2000);
            button1.Text = "Launch";
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            this.Text = "LOL System.user lololololoolololololololololol";
            this.Visible = false;
            await Task.Delay(1000);
            this.Visible = true;
            await Task.Delay(1000);
            this.Visible = false;
            await Task.Delay(1000);
            this.Visible = true;
            await Task.Delay(1000);
            this.Visible = false;
            await Task.Delay(1000);
            this.Visible = true;
            await Task.Delay(1000);
            this.Visible = false;
            await Task.Delay(1000);
            this.Visible = true;
            await Task.Delay(1000);
            this.Location = new Point(500);
            await Task.Delay(500);
            this.Location = new Point(200);
            await Task.Delay(500);
            this.Location = new Point(1300);
            await Task.Delay(500);
            this.Location = new Point(800);
            await Task.Delay(500);
            this.Location = new Point(5000);
            await Task.Delay(500);
            this.Location = new Point(490);
            await Task.Delay(500);
            this.Location = new Point(1);
            await Task.Delay(500);
            this.Location = new Point(2098889878);
            await Task.Delay(100);
            this.Location = new Point(92);
            await Task.Delay(100);
            this.Location = new Point(902);
            await Task.Delay(100);
            this.Location = new Point(920);
            await Task.Delay(100);
            this.Location = new Point(939040);
            await Task.Delay(100);
            this.Location = new Point(982);
            await Task.Delay(100);
            this.Location = new Point(22222);
            await Task.Delay(100);
            this.Location = new Point(78247);
            await Task.Delay(100);
            this.Location = new Point(82986);
            await Task.Delay(100);
            this.Location = new Point(009);
            this.Text = "X CXaokeqjoikfns,xgk,siwg";
            await Task.Delay(1000);
            this.Text = "LOL AU REVOIR";
            await Task.Delay(1000);
            Thread.Sleep(25000);
            Application.Restart();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "cmd")
            {
                Process.Start("cmd.exe");
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            this.ShowInTaskbar = false;
        }
    }
}
