﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Contrôle_de_Windows
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            button1.Visible = false;
            panel2.Visible = false;
            panel1.Visible = false;
            await Task.Delay(3000);
            label1.Text = @"Chargement de : Windows\System32";
            await Task.Delay(3000);
            label1.Text = @"Chargement de : Task.System32.DeviceCenter";
            await Task.Delay(2000);
            label1.Visible = false;
            panel1.Visible = true;
            pictureBox4.Visible = false;
            button1.Visible = true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Process.Start("explorer.exe");
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Process.Start("explorer.exe");
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Process.Start("shutdown", "/s /t 0");
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Process.Start("shutdown", "/r /t 0");
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Process.Start("shutdown", "/f /t 0");
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Process.Start("shutdown", "/h /t 0");
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
        }

        private void label7_Click_1(object sender, EventArgs e)
        {
            panel2.Visible = false;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Process.Start("control.exe");
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Process.Start("control.exe");
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Process.Start("ms-settings://");
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Process.Start("ms-settings://");
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Process.Start("ms-settings:appsfeatures");
        }

        private void label11_Click(object sender, EventArgs e)
        {
            Process.Start("ms-settings:appsfeatures");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new Form2().Show();
        }
    }
}
