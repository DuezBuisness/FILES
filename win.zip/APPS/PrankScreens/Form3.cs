﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Screens
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "restart")
            {
                Process.Start("shutdown", "/r /t 0");
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string path = @"C:\SCREENS.ASUSBIOS";
            Directory.CreateDirectory(path);
            string path2 = @"C:\SCREENS.ASUSBIOS\bios.cmd";
            string text = @"@echo off
color a
echo bios.access
pause
cls
echo scanning...
ping localhost -n 2 >nul
echo asusbios.dll
ping localhost -n 2 >nul
echo visualstudio.exe
ping localhost -n 2 >nul
echo system32.dll
ping localhost -n 2 >nul
echo device.windows32.config
ping localhost -n 2 >nul
echo bluetooth.exe[32bits]
ping localhost -n 2 >nul
echo devenv.exe[devenv.dll, process.start = visualstudio{devenv}, devenv.process.start]
ping localhost -n 2 >nul
cls
echo Votre ordinateur va redemarrer.
pause
shutdown /r /t 0
exit";
            File.WriteAllText(path2, text);
            this.TopMost = false;
            Process.Start(@"C:\SCREENS.ASUSBIOS\bios.cmd");
        }
    }
}
