﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace Screens
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private async void Form2_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;
            await Task.Delay(1000);
            label3.Text = "20% Complete";
            await Task.Delay(1000);
            label3.Text = "40% Complete";
            await Task.Delay(1000);
            label3.Text = "80% Complete";
            await Task.Delay(1000);
            label3.Text = "100% Complete";
            await Task.Delay(1000);
            Process.Start("shutdown", "/r /t 0");
        }

    }
}
