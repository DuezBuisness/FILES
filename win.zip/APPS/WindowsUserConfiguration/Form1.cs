﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsUserConfiguration
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            string path = @"C:\Config\User";
            Directory.CreateDirectory(path);
            string path2 = @"C:\Config\User\userid.rtp";
            string text = @"UserConfig = #{userconfigid:902047409}
-----------------------------------------
© Copyright 2024
Code.Config = UserConfig.Windows{config=true}, " + Environment.UserDomainName;
            File.WriteAllText(path2, text);
            string path3 = @"C:\Config\User\userDomain.xhtm";
            string text2 = @"XHTM ---- userDomain.xhtm
xhtm{file<userConfig>, [xhtm.file<userconfig>.configurate{xhtm{0}, {serverDomainName}, serverActive}, userConfig.configure], serverDomainName.WindowsDomainName.serverConfig}
{config[](object sender, EventArgs e)
{
   userId userId = new userId
   userId()
        .xhtm(configurate)
        .File.Sender(configurate)
        .Show(configurate)
        .xhtm.Close;
   configurate(userId)
}";
            File.WriteAllText(path3, text2);
            await Task.Delay(1000);
            label1.Text = @"Configure .sys files...";
            string path4 = @"C:\Config\User\userX.sys";
            string text3 = @"{userX.dev}";
            File.WriteAllText(path4, text3);
            await Task.Delay(1000);
            label1.Text = @"Finished !";
            await Task.Delay(1000);
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
