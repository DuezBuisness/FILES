﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ErrorSimulator
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            Thread.Sleep(1000);
            MessageBox.Show("YO");
            MessageBox.Show("Gnognokiki.exe bloqued");
            DialogResult result = MessageBox.Show("Error", "EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
            if (result == DialogResult.Abort)
            {
                Process.Start(@"C:\Windows\system32\cmd.exe");
                Application.Exit();
            }
            if (result == DialogResult.Retry)
            {
                MessageBox.Show("I SEE YOU", "I SEE YOU.exe SYSTEM32 I SEE YOU I SEE YOU SYSTEM I SEE YOU I SEE YOU.exe SYSTEM32.cmd.exe", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Thread.Sleep(1000);
                MessageBox.Show("Fail System Error !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!", "OMG");
                Application.Restart();
            }
            if (result == DialogResult.Ignore)
            {
                DialogResult result2 = MessageBox.Show("FAIL FAIL FAIL FAIL SYSTEM ERRRRRRRRROOOOOOOOOOOOOOR ! !! ! ! ! ! ! ! !!!! ! ! !! ! ", "ERROR SYSTEM32", MessageBoxButtons.YesNo);
                if (result2 == DialogResult.Yes)
                {
                    Form3 form3 = new Form3();
                    form3.Show();
                    Form3 form3_2 = new Form3();
                    form3_2.Show();
                    Form3 form3_3 = new Form3();
                    form3_3.Show();
                    Form3 form3_4 = new Form3();
                    form3_4.Show();
                    Form3 form3_5 = new Form3();
                    form3_5.Show();
                    Form3 form3_6 = new Form3();
                    form3_6.Show();
                    Form3 form3_7 = new Form3();
                    form3_7.Show();
                    Form3 form3_8 = new Form3();
                    form3_8.Show();
                    Form3 form3_9 = new Form3();
                    form3_9.Show();
                    Form3 form3_10 = new Form3();
                    form3_10.Show();
                    Form3 form3_11 = new Form3();
                    form3_11.Show();
                    Form3 form3_12 = new Form3();
                    form3_12.Show();
                    Form3 form3_13 = new Form3();
                    form3_13.Show();
                    Form3 form3_14 = new Form3();
                    form3_14.Show();
                    Form3 form3_15 = new Form3();
                    form3_15.Show();
                    Form3 form3_16 = new Form3();
                    form3_16.Show();
                    Form3 form3_17 = new Form3();
                    form3_17.Show();
                    Form3 form3_18 = new Form3();
                    form3_18.Show();
                    Form3 form3_19 = new Form3();
                    form3_19.Show();
                    Form3 form3_20 = new Form3();
                    form3_20.Show();
                    Form3 form3_21 = new Form3();
                    form3_21.Show();
                    Form3 form3_22 = new Form3();
                    form3_22.Show();
                    Form3 form3_23 = new Form3();
                    form3_23.Show();
                    Form3 form3_24 = new Form3();
                    form3_24.Show();
                    Form3 form3_25 = new Form3();
                    form3_25.Show();
                    Form3 form3_26 = new Form3();
                    form3_26.Show();
                    Form3 form3_27 = new Form3();
                    form3_27.Show();
                    Form3 form3_28 = new Form3();
                    form3_28.Show();
                    Form3 form3_29 = new Form3();
                    form3_29.Show();
                    Form3 form3_30 = new Form3();
                    form3_30.Show();
                    MessageBox.Show("I SEE YOU §§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§§", "HELLO  F  F KV OINDVNRIVINGF+BË", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Thread.Sleep(10000);
                    Form4 form4 = new Form4();
                    form4.Show();
                }
            }
        }
    }
}
