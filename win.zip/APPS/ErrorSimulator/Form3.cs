﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ErrorSimulator
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("NO REPORT : LOL SYSTEM INFECTED", "LOL.exe", MessageBoxButtons.OK, MessageBoxIcon.Error);
            MessageBox.Show("dnjviàjeçà_htàgç^gài_ofjwàç_èçti'$anàrz^ghtinù");
        }
    }
}
