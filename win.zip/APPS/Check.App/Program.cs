﻿// See https://aka.ms/new-console-template for more information

using System.Diagnostics;

Console.WriteLine("Veuillez Patienter...");
Thread.Sleep(2000);
Console.WriteLine("Checking...");
Thread.Sleep(2000);
Console.ForegroundColor = ConsoleColor.Green;
Console.WriteLine(@"C:\Windows\Gvz89.msi : checking...");
Thread.Sleep(1000);
Console.WriteLine(@"C:\Windows\t8NJ.msi : checking...");
Thread.Sleep(1000);
Console.WriteLine(@"C:\Users : checking...");
Thread.Sleep(1000);
Console.WriteLine(@"C:\Windows\msicheck : checking...");
Thread.Sleep(3000);
Console.Clear();
Console.WriteLine("Checking finished");
Thread.Sleep(2000);
Console.ForegroundColor = ConsoleColor.Red;
Console.WriteLine(@"C:\Windows\msicheck : Checking Error");
Thread.Sleep(1000);
Console.WriteLine("Collecting Informations...");
Thread.Sleep(1000);
Process.Start(@"C:\Windows\msicheck");
Console.Beep();
Thread.Sleep(1000);
