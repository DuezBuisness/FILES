﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace I_SEE_YOU.LOL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
            string path = @"C:\Program Files (x86)\PrankApps\I SEE YOU";
            Directory.CreateDirectory(path);
            string path2 = @"C:\Program Files (x86)\PrankApps\I SEE YOU\application.dev";
            string text = @"DevFile.dev
-------------------------
C#
SystemLinksInfomrations.sys
system.Application.System.C#
Sytem.C#
using System.IO
using System.C# //dev.info
Dev.C#.Application = System.Access";
            File.WriteAllText(path2, text);
            string path3 = @"C:\Program Files (x86)\PrankApps\I SEE YOU\application.sys";
            string text2 = @"File.System
C#.SYS
Windows.Version =  system.IO; .sys;
-----------------------------------
UEH9_€RZDIJb6ZUàaçàç#kz79°[^#@^[#^\[^#~998{~^#@@~\\{\\{\\{@^@#}}#}}UH9z398anUQL,88,0AH8?8S8##SUçàé";
            File.WriteAllText(path3, text2);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
        }

        private void label4_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void label5_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Unistall ?", "UNISTALL", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                MessageBox.Show("J'ai la flème, fais le toi même.", "NOOOOOOOOOOOO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Process.Start(@"C:\Program Files (x86)\PrankApps");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new Form2().Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            new Form4().Show();
        }
    }
}
