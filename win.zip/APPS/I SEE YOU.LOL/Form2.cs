﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace I_SEE_YOU.LOL
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            pictureBox2.Visible = false;
            this.TopMost = true;
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;
            BackColor = Color.Lime;
            TransparencyKey = Color.Lime;
            Thread.Sleep(5000);
            MessageBox.Show("Hello");
            MessageBox.Show("BYYYYEYYEYEYYEEYYEE");
            pictureBox1.Visible = false;
            pictureBox2.Visible = true;
            new Form3().Show();
        }
    }
}
