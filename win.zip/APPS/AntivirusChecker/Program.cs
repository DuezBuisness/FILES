﻿// See https://aka.ms/new-console-template for more information
using System.Diagnostics;

Console.WriteLine(@"Scanning...");
Console.ForegroundColor = ConsoleColor.Green;
Thread.Sleep(500);
Console.WriteLine(@"C:\");
Thread.Sleep(500);
Console.WriteLine(@"C:\Windows");
Thread.Sleep(500);
Console.WriteLine(@"C:\Users");
Console.WriteLine(@"Cliquez sur une touche pour continuer");
Console.ReadKey();
Console.Clear();
Console.WriteLine(@"Aucun problème n'a été détecté sur \windows\system32, C:\");
Console.WriteLine(@"Cliquez sur une touche pour fermer cette fenêtre");
Console.ReadKey();


