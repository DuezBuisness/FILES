﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WSF_Popup_LOL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string path = @"C:\WSF.POPUP.LOL";
            Directory.CreateDirectory(path);
            string path2 = @"C:\WSF.POPUP.LOL\lol.cmd";
            string text = @"@echo off
echo system.IO : system.Params.cmdBuilder()
echo system.IO : system.Params.cmd.taskmgr.show()
ping localhost -n 2 >nul
echo launch.WSF.Popup.LOL
pause
exit";
            File.WriteAllText(path2, text);
            Process.Start(@"C:\WSF.POPUP.LOL\lol.cmd");
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;
            MessageBox.Show("Hello");
            Process.Start("https://dl-protect.link");
            Process.Start("https://aka.ms");
            Process.Start("https://mapub.link");
            Process.Start("https://moi.net");
            Process.Start("https://hackertyper.com");
            Process.Start("mailto:666@666.net");
        }
    }
}
